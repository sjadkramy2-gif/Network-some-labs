@echo off

echo بدء نسخ النظام...

wbAdmin start backup -backupTarget:D: -include:C: -allCritical -quiet

echo تم نسخ النظام بنجاح
pause
