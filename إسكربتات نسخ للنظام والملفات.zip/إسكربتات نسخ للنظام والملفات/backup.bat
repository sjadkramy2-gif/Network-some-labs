@echo off

echo بدء النسخ الاحتياطي...

xcopy C:\Users D:\Backup /E /H /C /I /Y

echo تم النسخ بنجاح
pause
